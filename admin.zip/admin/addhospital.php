<?php include "header.php";?>
<?php include "sidemenu.php";?>
<div class="main-content">               
	<div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
            	<div class="col-lg-9">
                    <div class="card">
                        <div class="card-header">
                            <strong>Add Hospital</strong>
                        </div>
                        <div class="card-body card-block">
                        <form id="add_hospital" action="" method="POST">
                            <div class="form-group">
                                <label for="Name of Hospital" class=" form-control-label">Hospital Name</label>
                                <input type="text" id="name" placeholder="Enter Hospital name" class="form-control" required="Name">
                            </div>
                            <div class="form-group">
                                <label for="Address" class=" form-control-label">Address</label>
                                <input type="text" id="address" placeholder="Address" class="form-control" required="Address">
                            </div>
                            <div class="form-group">
                                <label for="Contact Number" class=" form-control-label">Contact Number</label>
                                <input type="text" id="contact_number" placeholder="Enter contact number" class="form-control" required="Contact number">
                            <div><br>
                            <div class="row form-group">
                                <div class="col-12 col-md-9">
                                    <label for="textarea-input" class=" form-control-label">Description</label>
                                    <textarea name="textarea-input" id="desc" rows="9" placeholder="Content..." class="form-control" required="description"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Email" class=" form-control-label">Email</label>
                                <input type="Email" id="email" placeholder="Email" class="form-control" required="Email">
                            </div>
                            <div class="form-group">
                                <label for="city" class=" form-control-label">City</label>
                                <input type="text" id="city" placeholder="Enter city" class="form-control" required="City">
                            </div>
                            <div class="form-group">
                                <label for="Established Year" class=" form-control-label">Established Year</label>
                                <input type="text" id="established_year" placeholder="Established Year" class="form-control" required="Established Year">
                            </div>
                        <!--    <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="file-input" class=" form-control-label">Hospital Logo</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <input type="file" id="file-input" name="file-input" class="form-control-file">
                                </div>
                            </div>-->
                            <div class="form-group">
                                <label for="Password" class=" form-control-label">Password</label>
                                <input type="password" id="password" placeholder="Enter Password" class="form-control" required="Password">
                            </div>
                            <div class="form-group">
                                <label for="regdate" class=" form-control-label">Registered Date</label>
                                <input type="date" id="regdate" placeholder="Enter Registered date" class="form-control" required="Registered date">
                            </div>
                            <div class="form-group">
                                <label for="state" class=" form-control-label">State</label>
                                <input type="text" id="state" placeholder="Enter state" class="form-control" required="state">
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm">
                                    <i class="fa fa-dot-circle-o"></i> Submit 
                                </button>
                                <a href="addhospital.php"  class="btn btn-danger btn-sm">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
 
<?php include "footer.php"; ?>
<script type="text/javascript" src="js/addhospital.js"></script>
