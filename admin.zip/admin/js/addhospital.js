var messagesRef = firebase.database().ref('hospital_tb');

document.getElementById('add_hospital').addEventListener('submit', submitForm);

function submitForm(e) {
    e.preventDefault();

    var name = getInputVal('name');
    var address = getInputVal('address');
    var contact_number = getInputVal('contact_number');
    var desc = getInputVal('desc');
    var email = getInputVal('email');
    var city = getInputVal('city');
    var established_year = getInputVal('established_year');
    var password = getInputVal('password');
    var regdate = getInputVal('regdate');
    var state = getInputVal('state');
    toastr.info("Please wait...");
    try{
        firebase.database().ref('hospital_tb').orderByChild('email').equalTo(email).once('value', snapshot => {
            if (snapshot.exists()) {
                toastr.info("Email ID Already Registered");
            }else{
                addnewrow.set(newMessageRef);
                location.href("addhospital.php");
            }
        });

    }catch{}
    saveMessage(name, address, contact_number, desc, email, city, established_year, password, regdate,state);

    document.getElementById("add_hospital").reset();
}

function getInputVal(id)
{
    return document.getElementById(id).value;
}

function saveMessage(name, address, contact_number, desc, email, city, established_year, password, regdate,state){
    var newMessageRef = messagesRef.push();
    newMessageRef.set({
        name : name,
        address : address,
        contact_number : contact_number,
        desc : desc,
        email : email,
        city : city,
        established_year : established_year,
        password : password,
        regdate : regdate,
        state : state,
        id : newMessageRef.key,
        logo : "",
        cover_page : ""   
         });
    toastr.success("Form Submited Successfuly!!!");
}

