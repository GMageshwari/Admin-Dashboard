$(window).on("load",function(){
    $("#loginForm").click(function(e)
    {
        e.preventDefault();
        var email = $('#email').val();
        console.log(email);
        var password = $('#password').val();
        const auth = firebase.auth();
        toastr.info("Please wait...");

        auth.signInWithEmailAndPassword(email,password).then((userCredential)=>
        {
            //signed in
            var user = userCredential.user;
            userinfo = new FormData();
            userinfo.append("uid", user.uid);
            userinfo.append("email", user.email);
            console.log(user);
            //set_session(userinfo);
            toastr.success("Welcome " + user.email);
           // window.alert("success");
            location.href="index.php";
        })
        .catch((error) => {       
            var emailCode = error.code;
            var errorMessage = error.message;
            toastr.error(error.message);
            console.log(error.message);
            }); 
    });
    })

  
/**
$.ajax({
    url: base_url + "admin/session_update",
    data: userinfo,
    type: "POST",
    processData: false,
    contentType: false,
    success: function(result){
        location.href = base_url + "admin/index";
    }
});**/

























