var messagesRef = firebase.database().ref('doctors_tb');

document.getElementById('add_doctor').addEventListener('submit', submitForm);

function submitForm(e) {
    e.preventDefault();

    var designation = getInputVal('designation');
    var dob = getInputVal('dob');
    var gender = getInputVal('gender');
    var email = getInputVal('email');
    var name = getInputVal('name');
    var phone = getInputVal('phone');
    var practicing_from = getInputVal('practicing_from');
    var profile = getInputVal('profile');
    var qualification = getInputVal('qualification');
    var regdate = getInputVal('regdate');
    toastr.info("Please wait...");
    
    saveMessage(designation, dob, gender, email, name, phone, practicing_from, profile, qualification, regdate);

    document.getElementById("add_doctor").reset();
}

function getInputVal(id)
{
    return document.getElementById(id).value;
}

function saveMessage(designation, dob, gender, email, name, phone, practicing_from, profile, qualification, regdate){
    var newMessageRef = messagesRef.push();
    newMessageRef.set({
        designation : designation,
        dob : dob,
        gender : gender,
        email : email,
        name : name,
        phone : phone,
        practicing_from : practicing_from,
        profile : profile,
        qualification : qualification,
        regdate : regdate,
        id : newMessageRef.key,  
         });
    toastr.success("Docor Added Successfuly!!!");
}

