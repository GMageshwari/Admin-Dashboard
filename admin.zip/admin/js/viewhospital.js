var messagesRef = firebase.database().ref('hospital_tb');

$(document).ready( function () {
	  var test = $('#viewhospital').DataTable();
	  
	messagesRef.on("child_added",snap=>{
	    var Name = snap.child("name").val();
	    var address = snap.child("address").val();
	    var contact_number = snap.child("contact_number").val();
	    var desc = snap.child("desc").val();
	    var email = snap.child("email").val();
	    var city = snap.child("city").val();
	    var established_year = snap.child("established_year").val();
	    var password = snap.child("password").val();
	    var regdate = snap.child("regdate").val();
	    var state = snap.child("state").val();

	   // $('#viewhospital').append("<tr><td>"+Name+"</td><td>"+address+"</td><td>"+contact_number+"</td><td>"
	        //+desc+"</td><td>"+email+"</td><td>"+city+"</td><td>"+established_year+"</td><td>"+password+"</td><td>"
	        //+regdate+"</td><td>"+state+"</td></tr>");
	        var dataset1 = [Name,address,contact_number,desc,email,city,established_year,password,regdate,state];                   
            test.rows.add([dataset1]).draw();
	});
});