<?php include "header.php";?>
<?php include "sidemenu.php";?>

<br>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
        	<div class="col-md-19">
        		<div class="table-data__tool-left">
					<button class="au-btn au-btn-icon au-btn--green au-btn--small">
					</button>
					<a href="add_doctor.php"  class="btn btn-secondary"> + Add Doctor </a>
			    </div><br>
				<div class="card">
					<div class="card-header">
                            <strong>View Vaccine List</strong>
                    </div>
					<div class="card-body">
						<div class="table-responsive">
							<table id="viewdoctor" class="table table-bordered">
								<thead>
									<tr>
										<th>Designation</th>
										<th>dob</th>
										<th>Gender</th>
										<th>Email</th>
										<th>Name</th>
										<th>Phone Number</th>
										<th>practicing From</th>
										<th>Profile</th>
										<th>Qualification</th>
										<th>Registertion Date</th>
									</tr>
								</thead>
								<tbody>
									
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>
<script>

		$(document).ready( function () {
	  	var test = $('#viewdoctor').DataTable();
	  	var messagesRef = firebase.database().ref('doctors_tb');
		//View Doctor
		messagesRef.on("child_added",snap=>{
		    var designation = snap.child("designation").val();
		    var dob = snap.child("dob").val();
		    var gender = snap.child("gender").val();
		    var email = snap.child("email").val();
		    var name = snap.child("name").val();
		    var phone = snap.child("phone").val();
		    var practicing_from = snap.child("practicing_from").val();
		    var profile = snap.child("profile'").val();
		    var qualification = snap.child("qualification").val();
		    var regdate = snap.child("regdate").val();
		    toastr.info("Please wait...");

		    var dataset1 = [designation,dob,gender,email,name,phone,practicing_from,profile,qualification,regdate];                   
            test.rows.add([dataset1]).draw();

		});

	});
</script>