<?php include "header.php";?>
<?php include "sidemenu.php";?>
<div class="main-content">               
	<div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
            	<div class="col-lg-9">
                            <div class="card">
                                    <div class="card-header">
                                        <strong>Child Appointment</strong>
                                    </div>
                                    <div class="card-body card-block">
                                        <div class="form-group">
                                            <label for="appdate" class=" form-control-label">Appointment date</label>
                                            <input type="date" id="appdate" placeholder="Appointment date" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="child height" class=" form-control-label">child height</label>
                                            <input type="text" id="childheight" placeholder="Enter child height" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="child weight" class=" form-control-label">child weight</label>
                                            <input type="text" id="childweight" placeholder="Enter child weight" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="child name" class=" form-control-label">child name</label>
                                            <input type="text" id="childname" placeholder="Enter child name" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="Date of registeration" class=" form-control-label">Date of registeration</label>
                                            <input type="date" id="regdate" placeholder="Date of registeration" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="status" class=" form-control-label">status</label>
                                            <input type="text" id="status" placeholder="status" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="Vaccmonth" class=" form-control-label">Vaccine month</label>
                                            <input type="text" id="Vaccmonth" placeholder="Vaccine month" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="Vaccine" class=" form-control-label">Vaccine</label>
                                            <input type="text" id="Vaccine" placeholder="Vaccine" class="form-control">
                                        </div>
                                        <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                         	<i class="fa fa-dot-circle-o"></i> Submit 
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php include "footer.php"; ?>