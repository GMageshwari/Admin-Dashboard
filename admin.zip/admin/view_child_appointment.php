<?php include "header.php";?>
<?php include "sidemenu.php";?>

<br>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
        	<div class="col-md-19">
				<div class="card">
					<div class="card-header">
                            <strong>View child Appointment List</strong>
                    </div>
					<div class="card-body">
						<div class="table-responsive">
							<table id="viewchild" class="table table-bordered">
								<thead>
									<tr>
										<th>Appointment_date</th>
										<th>Child height</th>
										<th>Child ID</th>
										<th>Child name</th>
										<th>Child weight</th>
										<th>Hospital id</th>
										<th>Parent id</th>
										<th>Registertion Date</th>
										<th>Status</th>
										<th>Vaccine Month</th>
										<th>Vaccines</th>
									</tr>
								</thead>
								<tbody>
									
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>
<script>

		$(document).ready( function () {
	  	var test = $('#viewchild').DataTable();
	  	var messagesRef = firebase.database().ref('child_appointment_tb/hosp_1');
		//View Doctor
		messagesRef.on("child_added",snap=>{
		    var appointment_date = snap.child("appointment_date").val();
		    var child_height  = snap.child("child_height").val();
		    var child_id = snap.child("child_id").val();
		    var child_name = snap.child("child_name").val();
		    var child_weight = snap.child("child_weight").val();
		    var hospital_id = snap.child("hospital_id").val();
		    var parent_id = snap.child("parent_id").val();
		    var regdate = snap.child("regdate").val();
		    var status = snap.child("status").val();
		    var vaccine_month = snap.child("vaccine_month").val();
		    var vaccines = snap.child("vaccines").val();
		    
		    toastr.info("Please wait...");

		    var dataset1 = [appointment_date,child_height,child_id,child_name,child_weight,hospital_id,parent_id,regdate,status,vaccine_month,vaccines];                   
            test.rows.add([dataset1]).draw();

		});

	});
</script>