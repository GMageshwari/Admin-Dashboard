<?php include "header.php";?>
<?php include "sidemenu.php";?>
<div class="main-content">               
	<div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
            	<div class="col-lg-9">
                    <div class="card">
                        <div class="card-header">
                            <strong>Add Doctors</strong>
                        </div>
                        <div class="card-body card-block">
                        <form id="add_doctor" action="" method="POST">
                                <div class="form-group">
                                    <label for="desigination" class=" form-control-label">Desigination</label>
                                    <input type="text" id="designation" placeholder="Enter desigination" required="desigination" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="DOB" class=" form-control-label">Date of Birth</label>
                                    <input type="date" id="dob" placeholder="Date of Birth" required="dob" class="form-control">
                                </div>
                                <div class="row form-group">
                                    <div class="col col-md-3">
                                        <label class=" form-control-label">Gender</label>
                                    </div>
                                    <div class="col col-md-9">
                                        <div class="form-check">
                                            <div class="radio">
                                                <label for="Female" class="form-check-label ">
                                                <input type="radio" id="gender" name="radios" value="Female" class="form-check-input">Female
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label for="Male" class="form-check-label ">
                                                <input type="radio" id="gender" name="radios" value="Male" class="form-check-input">Male
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label for="others" class="form-check-label ">
                                                <input type="radio" id="gender" name="radios" value="Others" class="form-check-input">Others
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="Email" class=" form-control-label">Email</label>
                                    <input type="Email" id="email" placeholder="Email" required="email" class="form-control">
                                </div>
                            <div class="form-group">
                                <label for="name" class=" form-control-label">Name</label>
                                <input type="text" id="name" placeholder="Name" required="Name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="Phone Number" class=" form-control-label">Phone Number</label>
                                <input type="text" id="phone" placeholder="Enter phone number" required="Phone Number" class="form-control">
                            </div>
                            <div class="form-group">
                                    <label for="practice" class=" form-control-label">Practicing form</label>
                                    <input type="date" id="practicing_from" placeholder="Practicing form" required="practice form" class="form-control">
                                </div>
                           <div class="col-12">
                                <div class="row form-group">
                                    <div class="col col-md-3">
                                        <label for="file-input" class=" form-control-label">Profile Picture</label>
                                    </div>
                                    <div class="col-12 col-md-9">
                                        <input type="file" id="profile" name="file-input" class="form-control-file">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                    <label for="Qualification" class=" form-control-label">Qualification</label>
                                    <input type="text" id="qualification" placeholder="qualification" required="Qualification" class="form-control">
                            </div>
                           <div class="form-group">
                                    <label for="regdate" class=" form-control-label">Registered Date</label>
                                    <input type="date" id="regdate" placeholder="Enter Registered date" required="Registered date" class="form-control">
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm">
                                    <i class="fa fa-dot-circle-o"></i> Submit 
                                </button>
                                <a href="add_doctor.php"  class="btn btn-danger btn-sm">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
                        
<?php include "footer.php"; ?>
<script type="text/javascript" src="js/add_doctor.js"></script>


