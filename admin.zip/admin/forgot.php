<?php include "header.php";?>
<?php include "loginsection.php";?>

    
<form id="forgot" action="" method="post">
    <div class="form-group">
        <label>User name</label>
        <input class="au-input au-input--full" type="text" name="username" placeholder="Enter Username" required>
    </div>
    <div class="form-group">
     <input type="hidden" name="forgot" value="forgot">
     <button class="au-btn au-btn--block au-btn--green m-b-20">
     sign in</button>
    </div>
            
                                
</form>
    <div class="register-link">
        <p>
            Remember Password?
            <a href="login.php">Login</a>
        </p>
    </div>
<?php include "footer.php";?>

