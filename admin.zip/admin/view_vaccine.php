<?php include "header.php";?>
<?php include "sidemenu.php";?>
<br>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
        	<div class="col-md-10">
				<div class="card">
					<div class="card-header">
                            <strong>View Vaccine List</strong>
                    </div>
					<div class="card-body">
						<div class="table-responsive">
							<table id="viewvaccine" class="table table-bordered">
								<thead>
									<tr>
										<th>ID</th>
										<th>Name</th>
										<th>Description</th>
										<th>RegDate</th>
									</tr>
								</thead>
								<tbody>
									
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>
<script>

		$(document).ready( function () {
	  	var test = $('#viewvaccine').DataTable();
	  	var messagesRef = firebase.database().ref('vaccine_detail_tb');
		//View vaccine
		messagesRef.on("child_added",snap=>{
		    var id = snap.child("id").val();
		    var name = snap.child("name").val();
		    var description = snap.child("description").val();
		    var regdate = snap.child("regdate'").val();
		    toastr.info("Please wait...");
		    //$('#viewvaccine').append("<tr><td>"+id+"</td><td>"+name+"</td><td>"+description+"</td><td>"+regdate+"</td></tr>");

		    var dataset1 = [id, name,description,regdate];                   
            test.rows.add([dataset1]).draw();

		});

	});
</script>