<?php include "header.php";?>
<?php include "loginsection.php";?>
<form id="login" action="" method="post">    
    <div class="form-group">
        <label>Email</label>
        <input class="au-input au-input--full" type="email" name="Email" id="email" 
        placeholder="Email" required="Username">
    </div>
    <div class="form-group">
        <label>Password</label>
        <input class="au-input au-input--full" type="password" name="password" id="password" placeholder="Password" required="password">
    </div>
    <div class="login-checkbox">
        <label>
            <input type="checkbox" name="remember">Remember Me
        </label>
        <label>
            <a href="forgot.php">Forgotten Password?</a>
        </label>
    </div>

    <div class="au-btn au-btn--block au-btn--green m-b-20">
     <input type="hidden" name="loginSubmit" value="loginSubmit">
     <button id="loginForm" class="au-btn au-btn--block au-btn--green m-b-20">
     sign in</button>
    </div>           
</form>
 

<?php include "footer.php";?>
 <script type="text/javascript" src="js/login.js"></script>
