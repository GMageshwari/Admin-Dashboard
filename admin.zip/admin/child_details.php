<?php include "header.php";?>
<?php include "sidemenu.php";?>
<div class="main-content">               
	<div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
            	<div class="col-lg-9">
                            <div class="card">
                                    <div class="card-header">
                                        <strong>Child Details</strong>
                                    </div>
                                    <div class="card-body card-block">
                                        
                                        <div class="form-group">
                                            <label for="child name" class=" form-control-label">child name</label>
                                            <input type="text" id="childname" placeholder="Enter child name" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="dob" class=" form-control-label">DOB</label>
                                            <input type="date" id="dob" placeholder="Enter Date of Birth" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="address" class=" form-control-label">address</label>
                                            <input type="text" id="address" placeholder="Enter address" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="doctor name" class=" form-control-label">doctor name</label>
                                            <input type="text" id="docname" placeholder="Enter doctor name" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="Father name" class=" form-control-label">Father name</label>
                                            <input type="text" id="fathername" placeholder="Enter Father name" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="Mother name" class=" form-control-label">Mother name</label>
                                            <input type="text" id="mothername" placeholder="Enter Mother name" class="form-control">
                                        </div>
                                        <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Gender</label>
                                                </div>
                                                <div class="col col-md-9">
                                                    <div class="form-check">
                                                        <div class="radio">
                                                            <label for="Female" class="form-check-label ">
                                                                <input type="radio" id="Female" name="radios" value="option1" class="form-check-input">Female
                                                            </label>
                                                        </div>
                                                        <div class="radio">
                                                            <label for="Male" class="form-check-label ">
                                                                <input type="radio" id="Male" name="radios" value="option2" class="form-check-input">Male
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <div class="form-group">
                                            <label for="Date of registeration" class=" form-control-label">Date of registeration</label>
                                            <input type="date" id="regdate" placeholder="Date of registeration" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="Contact Number" class=" form-control-label">Contact Number</label>
                                            <input type="text" id="contact" placeholder="Enter contact number" class="form-control">
                                        </div>
                                        <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                         	<i class="fa fa-dot-circle-o"></i> Submit 
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php include "footer.php"; ?>