<?php include "header.php";?>
<?php include "sidemenu.php";?>

<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="col-md-15">
                <div class="table-data__tool-left">
                    <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                    </button>
                    <a href="addhospital.php"  class="btn btn-secondary"> + Add Hospital </a>
                </div><br>
                <div class="card">
                    <div class="card-header">
                            <strong>View Hospital</strong>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="viewhospital" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>Contact number</th>
                                        <th>Description</th>
                                        <th>Email</th>
                                        <th>City</th>
                                        <th>Established year</th>
                                        <th>Password</th>
                                        <th>Registered date</th>
                                        <th>state</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
<script type="text/javascript" src="js/viewhospital.js"></script>

